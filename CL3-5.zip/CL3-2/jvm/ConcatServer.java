import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
 
public class ConcatServer { 
    public static void main(String[] args) { 
        try { 
            ConcatServiceImpl obj = new ConcatServiceImpl(); 
            Registry registry = LocateRegistry.createRegistry(1099); // default RMI port 
            registry.rebind("ConcatService", obj); 
            System.out.println("Server is ready."); 
        } catch (Exception e) { 
            System.out.println("Server excep on: " + e.toString()); 
            e.printStackTrace(); 
        } 
    } 
} 