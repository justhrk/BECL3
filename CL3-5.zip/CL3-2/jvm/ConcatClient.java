import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
 
public class ConcatClient { 
    public static void main(String[] args) { 
        try { 
            Registry registry = LocateRegistry.getRegistry("localhost"); 
            ConcatService stub = (ConcatService) registry.lookup("ConcatService"); 
 
            String str1 = "Hello, "; 
            String str2 = "World!"; 
            String response = stub.concatenate(str1, str2); 
 
            System.out.println("Concatenated Result: " + response); 
        } catch (Exception e) { 
            System.out.println("Client excep on: " + e.toString()); 
            e.printStackTrace(); 
        } 
    } 
} 