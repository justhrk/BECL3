import numpy as np 
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split 
from sklearn.metrics import classification_report, confusion_matrix 
from sklearn.preprocessing import MinMaxScaler 
from collections import namedtuple 
 
np.random.seed(42) 
 
def generate_structural_data(n_samples=300): 
    # Class 0: No Damage 
    class_0 = np.random.normal(loc=[0.2, 0.1, 0.3], scale=0.05, size=(n_samples, 3)) 
    # Class 1: Minor Damage 
    class_1 = np.random.normal(loc=[0.5, 0.6, 0.4], scale=0.07, size=(n_samples, 3)) 
    # Class 2: Major Damage 
    class_2 = np.random.normal(loc=[0.9, 0.8, 0.7], scale=0.05, size=(n_samples, 3)) 
 
    X = np.vstack((class_0, class_1, class_2)) 
    y = np.array([0]*n_samples + [1]*n_samples + [2]*n_samples) 
 
    return X, y 
 
X, y = generate_structural_data() 
scaler = MinMaxScaler() 
X = scaler.fit_transform(X) 
 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3) 
 
Antibody = namedtuple("Antibody", ["features", "label", "affinity"]) 
 
class AISClassifier: 
    def __init__(self, n_clones=10, n_generations=20): 
        self.memory_cells = [] 
        self.n_clones = n_clones 
        self.n_generations = n_generations 
 
    def affinity(self, a, b): 
        return 1.0 / (1.0 + np.linalg.norm(a - b)) 
 
    def train(self, X, y): 
        self.memory_cells = [] 
 
        for _ in range(self.n_generations): 
            population = [] 
 
            # Create ini al an bodies from training data 
            for i in range(len(X)): 
                antibody = Antibody(X[i], y[i], 1.0) 
                population.append(antibody) 
 
            # Clone and mutate 
            clones = [] 
            for ab in population: 
                for _ in range(self.n_clones): 
                    mutation = ab.features + np.random.normal(0, 0.1, size=len(ab.features)) 
                    mutated = np.clip(mutation, 0, 1) 
                    clones.append(Antibody(mutated, ab.label, self.affinity(mutated, ab.features))) 
 
            # Select best clones to memory cells 
            all_ab = population + clones 
            all_ab.sort(key=lambda x: x.affinity, reverse=True) 
            self.memory_cells = all_ab[:len(set(y)) * 10]  # keep top 10 per class 
 
    def predict(self, X): 
        predictions = [] 
        for x in X: 
            best = max(self.memory_cells, key=lambda ab: self.affinity(x, ab.features)) 
            predictions.append(best.label) 
        return np.array(predictions) 
 
model = AISClassifier() 
model.train(X_train, y_train) 
predictions = model.predict(X_test) 
 
print("\n Classifica on Report:") 
print(classification_report(y_test, predictions)) 
 
print(" Confusion Matrix:") 
print(confusion_matrix(y_test, predictions))